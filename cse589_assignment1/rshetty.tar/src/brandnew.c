/***reference:
http://www.binarytides.com/socket-programming-c-linux-tutorial/
http://www.binarytides.com/server-client-example-c-sockets-linux/
http://www.binarytides.com/multiple-socket-connections-fdset-select-linux/
http://beej.us/guide/bgnet/output/html/singlepage/bgnet.html
http://mcalabprogram.blogspot.com/2012/01/ftp-sockets-server-client-using-c.html
***/

/*
creator:rshetty
person# 50133314
*/




#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<errno.h>
#include<netdb.h>

#include<arpa/inet.h>
#include<sys/time.h>
#include <netinet/in.h>

#include<string.h>
#include<sys/socket.h>

#include<signal.h>

#define length 800

#define TRUE   1
#define FALSE  0



int i=0,j=0;

char* MY_IP;
static char ipaddr[100];

int portno;
static int clsockfd;
static int peerconsockfd;
static char *passVal[30];
int maxclients=4;
static int clientfd[4];
static char myhost[1024];

struct servL
{
	int id;
	char hostname[2000];
	char ipaddr[100];
	int portno;
	int sockfd;
};

struct cltL
{
	int id;
	char hostname[2000];
	char ipaddr[100];
	int portno;
	int sockfd;
};



char* myip()
{
			char choice='y';


			/*Variable declarations*/
			struct addrinfo hints, *info, *p;

			struct sockaddr_in *sa;
			struct sockaddr_in6 *sa6;

			int gai_result; // For result of getaddrinfo()

			char hostname[1024]; //For hostname
			hostname[1023] = '\0';
			//char ip_addr[100]; //For IP
			ipaddr[100]='\0';


			gethostname(hostname, 1023);
			printf("\nHostname: %s\n", hostname);


			/*Using modern getaddrinfo and sockaddr*/
			/*set hints parameters to call specific addrinfo*/
			memset(&hints, 0, sizeof hints);
			hints.ai_family = AF_UNSPEC; /*either IPV4 or IPV6*/
			hints.ai_socktype = SOCK_STREAM;
			hints.ai_flags = AI_CANONNAME;

			/*getaddrinfo + standard error check*/

			/****************check with second parameter null********************************************/
			if ((gai_result = getaddrinfo(hostname, "http", &hints, &info)) != 0) {
			    fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(gai_result));
			    exit(1);
			}

			/* loop through all the results and connect to the first we can */
			for(p = info; p != NULL; p = p->ai_next) {

				printf("\nHostname: %s\n", p->ai_canonname);  //For printing hostname


				//sa = (struct sockaddr_in *) p->ai_addr; //Get binary address *****Test 1.a with only this and deprecated on 1.b this and deprecated off****

				/* Deprecated way - for ip address --- start
				strcpy(ip_addr , inet_ntoa( sa->sin_addr ) );
				printf("IP address: %s" , ip_addr);
				Deprecated way - for ip address --- end */


				/* for IPv4 or IPV6 using ntop - n/w to presentation - beejguide*/
				switch(p->ai_family) {
					case AF_INET:
						sa = (struct sockaddr_in *) p->ai_addr; //Get binary address ***** Test 2 with this and below active
						inet_ntop(AF_INET, &(((struct sockaddr_in *)sa)->sin_addr), ipaddr, 99);
						break;

					case AF_INET6:
						sa6 = (struct sockaddr_in *) p->ai_addr; //Get binary address in case  ***** Test 2 with this and above active
						inet_ntop(AF_INET6, &(((struct sockaddr_in6 *)sa)->sin6_addr), ipaddr, 99);
	            		break;

					default:
						strncpy(ipaddr, "Unknown AF", 99);
	            		return ;
	    			}
				printf("\nIP address : %s", ipaddr);
				return ipaddr;
			}

			//freeaddrinfo(info);

			//return ;
}





void server (char var, char **argv)
{
	MY_IP=myip();
	portno=atoi(argv[2]);
    int opt = TRUE;
    int master_socket , addrlen , new_socket , client_socket[30] , max_clients = 4 , activity, i=0,j=0 , valread , sd;
    int max_sd;
    struct sockaddr_in address;
    int argc=0;
    char buffer[1025];
    char temp[10];

    char *pt;
    char *userinput[3];
    char input[1024];

	char hostname[2000];

    struct sockaddr_in *sa, sin; //IPV4
    struct hostent *hostentry;
    struct sockaddr_in6 *sa6; // IPV6

    int gaioutput;


    //set of socket descriptors
    fd_set readfds;

    //a message
    char *message = "ECHO Daemon v1.0 \r\n";

    //initialise all client_socket[] to 0 so not checked
    for (i = 0; i < max_clients; i++)
    {
        client_socket[i] = 0;
    }


    struct addrinfo hints, *info, *p;

    gethostname(hostname, 2000);
    printf("\nhostname: %s\n", hostname);


    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_CANONNAME;

    if ((gaioutput = getaddrinfo(hostname, argv[2], &hints, &info)) != 0)
    {
    	printf("getaddrinfo failed\n");
    	exit(1);
    }

    //init server
    struct servL s[5];
    for (i=0;i<5;i++)
    {
    	s[i].id=0;
    	strcpy(s[i].hostname,"...");
    	strcpy(s[i].ipaddr,"...");
    	s[i].portno=0;
    	s[i].sockfd=0;
    }

    //Set id of server
    s[0].id=1;



    for(p = info; p != NULL; p = p->ai_next)
    {
    	//create a master socket
    	if( (master_socket = socket(p->ai_family, p->ai_socktype, IPPROTO_TCP)) == 0)
    	{
    		perror("socket failed");
    		exit(EXIT_FAILURE);
    	}

    	//set master socket to allow multiple connections , this is just a good habit, it will work without this
    	if( setsockopt(master_socket, SOL_SOCKET, SO_REUSEADDR, (char *)&opt, sizeof(opt)) < 0 )
    	{
    		perror("setsockopt");
    		exit(EXIT_FAILURE);
    	}




    	//type of socket created
    	address.sin_family = AF_INET;
    	address.sin_addr.s_addr = INADDR_ANY;
    	address.sin_port = htons( portno );

    	//bind the socket to localhost port 8888
    	if (bind(master_socket, p->ai_addr, p->ai_addrlen)<0)
    	{
    		perror("bind failed");
    		exit(EXIT_FAILURE);
    	}
    	printf("Listener on port %d \n", portno);

    	//try to specify maximum of 3 pending connections for the master socket
    	if (listen(master_socket, 5) < 0)
    	{
    		perror("listen");
    		exit(EXIT_FAILURE);
    	}

    	//accept the incoming connection
    	addrlen = sizeof(address);
    	puts("Waiting for connections ...");


    	while(1)
    	{
    		//clear the socket set
    		FD_ZERO(&readfds);

    		//add master socket to set
    		FD_SET(master_socket, &readfds);
    		max_sd = master_socket;
    		FD_SET(0, &readfds);        // for taking input

    		//add child sockets to set
    		for ( i = 0 ; i < max_clients ; i++)
    		{
    			//socket descriptor
    			sd = client_socket[i];

    			//if valid socket descriptor then add to read list
    			if(sd > 0)
                FD_SET( sd , &readfds);

    			//highest file descriptor number, need it for the select function
    			if(sd > max_sd)
                max_sd = sd;
    		}

    		//wait for an activity on one of the sockets , timeout is NULL , so wait indefinitely
    		activity = select( max_sd + 1 , &readfds , NULL , NULL , NULL);

    		if ((activity < 0) && (errno!=EINTR))
    		{
    			printf("select error");
    		}



    		if (FD_ISSET(0, &readfds))
    		{


    			gets(input);

    			i = 0;
    			int k=0;

    			pt = strtok (input," ");


    			while (pt!= NULL)
    			{

    				userinput[i++] = pt;
    				pt = strtok (NULL," ");

    			}



    			/*argc=0;
    			pt=strtok(input," ");
    			while(pt != NULL)
    			{
    				strcpy(argv[argc],pt);
    				argc +=1;
    				pt=strtok(NULL," ");
    			}*/




    			//CREATOR

    			if (strcmp(userinput[0],"creator")==0)
    			{
    				printf("\nCREATOR\n");
    				printf("\n\nUBIT name : rshetty \nUBemail: rshetty@buffalo.edu\n");
    				printf("\nI have read and understood the course academic integrity policy at http://www.cse.buffalo.edu/faculty/dimitrio/courses/cse4589_f14/index.html#integrity\n\n");

    			}




    			//HELP

    			else if (strcmp(userinput[0],"help")==0)
    			{
    				printf("\nHELP\n");
    				printf("\n welcome to the help menu,all the commands that can be used are given below\n\n");
    				printf("\n creator: information of the creator can be found here\n");
    				printf("\n myip: ipaddress of the process\n");
    				printf("\n myport : used to display the port number on which the machine is listening for incoming connections\n");
    				printf("\n register <server ip> <port> : register with server whos ip is <server ip> and port number is<port>\n");
    				printf("\n connect <destination> <port> : connect to a fellow client by providing hostname/ip and port number\n");
    				printf("\n list : list of all active connections is displayed\n");
    				printf("\n terminate <connection id> : connection mentioned through <connection id> will be terminated\n");
    				printf("\n exit : all connections will be terminated\n");
    				printf("\n upload <connection_id> <file_name> : the file specified at<file_name> is uploaded to the mentioned <connection_id>\n");
    				printf("\n download <connection_id1> <file_name1> <connection_id2> <file_name2> <connection_id3> <file_name3> : download files from serveres specified through <connection_id1> <connection_id2> <connection_id3> \n");
    				printf("\n statistics : servers updated statistics is displayed \n for client display client statistics \n");
    				printf("\n");

    			}






    			//IP


    			else if (strcmp(userinput[0],"myip")==0)
    			{
    				strcpy(ipaddr,myip());
    				printf("%s",ipaddr);
    			}







    			//PORT


    			else if (strcmp(userinput[0],"myport")==0)
    			{



        			int size = sizeof(struct sockaddr);
        			if (getsockname(master_socket, (struct sockaddr *)&sin, &size) == -1)
        			{
        				perror("\n getsockname \n");
        			}
        			else
        			{
        				portno=ntohs(sin.sin_port);
        				printf("\n port number:%d\n",portno);
        				//return portno;
        			}
        		}




    			//EXIT

    			else if (strcmp(userinput[0],"exit")==0)
    			{

    				printf("\n server must keep running at all times \n");
    			}



    			//LIST
    			else if (strcmp(userinput[0],"list")==0)
    			{
    				printf("\n\n");
    				s[0].portno=portno;
    				strcpy(s[0].hostname,hostname);
    				strcpy(s[0].ipaddr,MY_IP);//.............

    				int size = sizeof(struct sockaddr);
    				if (getsockname(master_socket, (struct sockaddr *)&sin, &size) == -1)
    				{
    					perror("getsockname");
    				}
    				else
    				{
    					portno=ntohs(sin.sin_port);
    				}



    				printf("%-5s%-35s%-20s%-8s\n","ID","HOSTNAME","IPADDRESS","PORT");
    				i=0; //Re-declaration;
    				for (i=0;i<5;i++)
    				{
    					if (s[i].id!=0)
    					{

    						printf("%-5d%-35s%-20s%-8d\n",(--s[i].id),s[i].hostname,s[i].ipaddr,s[i].portno);
    					}
    					else
    					{
    						printf("%-5d%-35s%-20s%-8d\n",s[i].id,s[i].hostname,s[i].ipaddr,s[i].portno);
    					}

    				}
    			}


    			else
    			{
    				printf("\n error: invalid command check list of commands using help\n");
    			}



    		}




    		//If something happened on the master socket , then its an incoming connection
    		if (FD_ISSET(master_socket, &readfds))
    		{

    			struct sockaddr_in client;
    			int lenc=sizeof(client);
    			if ((new_socket = accept(master_socket, (struct sockaddr *)&client, (socklen_t*)&lenc))<0)
    			{
    				perror("accept");
    				exit(EXIT_FAILURE);
    			}
    			bzero(buffer,1025);
    			//inform user of socket number - used in send and receive commands

    			//send new connection greeting message
    		//	if( send(new_socket, message, strlen(message), 0) != strlen(message) )
    		//	{
    		//		perror("send");
    		//	}
    		//	puts("Welcome message sent successfully");

  				if (recv(new_socket, buffer, 2048,0) < 0)
  				{
  					puts("\nrecv failed\n");
  					break;
  				}
  				else
  				{
  					printf("\n portno of client : %s\n",buffer);

  					printf("\n");
  				}




  				printf("New connection , socket fd is %d , ip is : %s , port : %d \n" , new_socket , inet_ntoa(client.sin_addr) ,ntohs(client.sin_port) );





    			//bzero(buffer,1025);
    			//strcpy(buffer,inet_ntoa(client.sin_addr));
    			//add new socket to array of sockets
    			for (i = 0; i < max_clients; i++)
    			{
    				//if position is empty
    				if( client_socket[i] == 0 )
    				{
    					client_socket[i] = new_socket;
    					printf("Adding to list of sockets as %d\n" , i);

    					break;
    				}
    			}
    			//Add to list

    			for (j=1;j<5;j++)
    			{
    				if (s[j].id==0)
    				{
    					s[j].id=j+1;
    					hostentry=gethostbyaddr(&client.sin_addr, sizeof (client.sin_addr), AF_INET);
    					strcpy(s[j].hostname,hostentry->h_name);
    					inet_ntop(AF_INET, &client.sin_addr, s[j].ipaddr, 99);
    					s[j].portno=buffer; //String to integer
    					s[j].sockfd=new_socket;
    					break;
    				}
    			}

    			bzero(buffer,1025);

    			//server list sent to all

    			for (i = 0; i < 5; i++)
    			{
    				if (s[i].id != 0 )
    				{

    					sprintf(temp,"%d",s[i].id); // convert int to string
    					strcat(buffer,temp);
    					strcat(buffer," ");
    					strcat(buffer,s[i].hostname);
    					strcat(buffer," ");
    					strcat(buffer,s[i].ipaddr);
    					strcat(buffer," ");
    					sprintf(temp,"%d",s[i].portno); //convert int to string
    					strcat(buffer,temp);
    					strcat(buffer," ");
    					printf("\n\nMessage in buffer is %s\n\n",buffer);
    				}
    			}

    			// Send server clients list to all connected except itself
    			for (i = 1; i < 5; i++)
    			{
    				if (s[i].id != 0 )
    				{
    					printf("\n\n sockfd=%d \n\n",s[i].sockfd);

    					if( send(s[i].sockfd, buffer , strlen(buffer) , 0) < 0)
    					{
    						puts("\n send failed\n");
    		            					return;
    					}
    					else
    					{
    						printf("\n list sent to client sockets successfully\n");
    					}
    				}
    			}


    		}

    		//else its some IO operation on some other socket :)
    		for (i = 0; i < max_clients; i++)
    		{
    			sd = client_socket[i];
    			if(client_socket[i]>0)
    			{
    				if (FD_ISSET( sd , &readfds))
    				{
    					bzero(buffer,1025);
    					//Check if it was for closing , and also read the incoming message
    					if ((valread = read( sd , buffer, 1025)) == 0)
    					{
    						//Somebody disconnected , get his details and print
    						getpeername(sd , (struct sockaddr*)&address , (socklen_t*)&addrlen);
    						printf("Host disconnected , ip %s , port %d \n" , inet_ntoa(address.sin_addr) , ntohs(address.sin_port));

    						//Close the socket and mark as 0 in list for reuse
    						close( sd );
    						client_socket[i] = 0;
    					}

    					//Echo back the message that came in
    					else if (strcmp(buffer,"terminate")==0)
    					{
    						for (i=0;i<maxclients;i++)
    						{
    							if (new_socket==clientfd[i])
    								clientfd[i]=-1;
    							if (s[i].sockfd==new_socket)
    							{
    								s[i].id=0;
    								strcpy(s[i].hostname,"...");
    								strcpy(s[i].ipaddr,"...");
    								s[i].portno=0;
    								s[i].sockfd=0;
    							}
    						}

    						if(send(sd , buffer , strlen(buffer) , 0 )==0)
    						{
    							puts("Send failed");
    							return;
    						}
    						else
    						{
    							printf("Socket id %d has been deleted",new_socket);
    							close(new_socket);
    							bzero(buffer,1025);

    							//send servL to all
    							for (i = 0; i < 5; i++)
    							{
    								if (s[i].id != 0 )
    								{
    									sprintf(temp,"%d",s[i].id); // convert int to string
    									strcat(buffer,temp);
    									strcat(buffer," ");
    									strcat(buffer,s[i].hostname);
    									strcat(buffer," ");
    									strcat(buffer,s[i].ipaddr);
    									strcat(buffer," ");
    									sprintf(temp,"%d",s[i].portno); 								//convert int to string
    									strcat(buffer,temp);
    									strcat(buffer," ");
    									printf("\n\nMessage in buffer is %s\n\n",buffer);
    								}
    							}

    							// send server's client list to all connected except itself
    							for (i = 1; i < 5; i++)
    							{
    								if (s[i].id != 0 )
    								{
    									printf("\n\n sock FD :%d\n\n",s[i].sockfd);

    									if( send(s[i].sockfd, buffer , strlen(buffer) , 0) < 0)
    									{
    										puts("\nSend failed:server list to clients\n");
    										return;
    									}
    									else
    										printf("\nserver list to clients sent successfully\n");
    								}
    							}
    						}



    					}
    				}
    			}
    		}

    	}
    }
    freeaddrinfo(info);
}



struct statistics
{
	int id;
	char host1[100];
	char host2[100];
	double uploadtime;
	int uploadnum;
	double downloadtime;
	int downloadnum;
};




void client (char var, char **argv)
{
		MY_IP=myip();
		portno=atoi(argv[2]);
		int n;
	    int opt = TRUE;
	    int master_socket , addrlen , new_socket ,terminatesock, client_socket[30] , max_clients = 4 , activity, i=0,j=0 , valread , sd;
	    int max_sd;
	    struct sockaddr_in address;
	    int argc=0;
	    char buffer[1025];

	    char *pt;
	    char *userinput[3];
	    char input[1024];

		char hostname[2000];

	    struct sockaddr_in *sa, sin; //IPV4
	    struct hostent *hostentry;
	    struct sockaddr_in6 *sa6; // IPV6

	    int gaioutput;
	    int len;
	    int writesize;
	    struct timeval start,end;
	    double timeS;
	    double txnrate;
	    char uploadbuffer[length];


	    //set of socket descriptors
	    fd_set readfds;

	    //a message
	    char *message = "dummy message\n";

	    //initialise all client_socket[] to 0 so not checked
	    for (i = 0; i < max_clients; i++)
	    {
	        client_socket[i] = 0;
	    }


	    struct addrinfo hints, *info, *p;

	    gethostname(hostname, 2000);
	    printf("\nhostname: %s\n", hostname);
	    strcpy(myhost,hostname);

	    memset(&hints, 0, sizeof hints);
	    hints.ai_family = AF_UNSPEC;
	    hints.ai_socktype = SOCK_STREAM;
	    hints.ai_flags = AI_CANONNAME;

	    if ((gaioutput = getaddrinfo(hostname, argv[2], &hints, &info)) != 0)
	    {
	    	printf("getaddrinfo failed\n");
	    	exit(1);
	    }

	    //init server
	    struct servL s[5];
	    for (i=0;i<5;i++)
	    {
	    	s[i].id=0;
	    	strcpy(s[i].hostname,"...");
	    	strcpy(s[i].ipaddr,"...");
	    	s[i].portno=0;
	    	s[i].sockfd=0;
	    }

	    //Set id of server
	    s[0].id=1;

	    struct cltL c[4];
	    for (i=0;i<maxclients;i++)
	    {
	    	c[i].id=0;
	    	strcpy(c[i].hostname,"...");
	    	strcpy(c[i].ipaddr,"...");
	    	c[i].portno=0;
	    	c[i].sockfd=0;
	    }


	    struct statistics st[30];
	    for (i=0;i<30;i++)
	    {
	    	st[i].id=0;
	    	strcpy(st[i].host1,"...");
	    	strcpy(st[i].host2,"...");
	    	st[i].uploadtime=0;
	    	st[i].uploadnum=0;
	    	st[i].downloadtime=0;
	    	st[i].downloadnum=0;

	    }



	    for(p = info; p != NULL; p = p->ai_next)
	    {
	    	//create a master socket
	    	if( (master_socket = socket(p->ai_family, p->ai_socktype, IPPROTO_TCP)) == 0)
	    	{
	    		perror("socket failed");
	    		exit(EXIT_FAILURE);
	    	}

	    	//set master socket to allow multiple connections , this is just a good habit, it will work without this
	    	if( setsockopt(master_socket, SOL_SOCKET, SO_REUSEADDR, (char *)&opt, sizeof(opt)) < 0 )
	    	{
	    		perror("setsockopt");
	    		exit(EXIT_FAILURE);
	    	}




	    	//type of socket created
	    	address.sin_family = AF_INET;
	    	address.sin_addr.s_addr = INADDR_ANY;
	    	address.sin_port = htons( portno );

	    	//bind the socket to localhost port 8888
	    	if (bind(master_socket, p->ai_addr, p->ai_addrlen)<0)
	    	{
	    		perror("bind failed");
	    		exit(EXIT_FAILURE);
	    	}
	    	printf("Listener on port %d \n", portno);

	    	//try to specify maximum of 3 pending connections for the master socket
	    	if (listen(master_socket, 5) < 0)
	    	{
	    		perror("listen");
	    		exit(EXIT_FAILURE);
	    	}

	    	//accept the incoming connection
	    	addrlen = sizeof(address);
	    	puts("Waiting for connections ...");


	    	while(1)
	    	{
	    		//clear the socket set
	    		FD_ZERO(&readfds);

	    		//add master socket to set
	    		FD_SET(master_socket, &readfds);
	    		max_sd = master_socket;
	    		FD_SET(0, &readfds);        // for taking input

	    		//add child sockets to set
	    		for ( i = 0 ; i < max_clients ; i++)
	    		{
	    			//socket descriptor
	    			sd = client_socket[i];

	    			//if valid socket descriptor then add to read list
	    			if(sd > 0)
	                FD_SET( sd , &readfds);

	    			//highest file descriptor number, need it for the select function
	    			if(sd > max_sd)
	                max_sd = sd;
	    		}

	    		//wait for an activity on one of the sockets , timeout is NULL , so wait indefinitely
	    		activity = select( max_sd + 1 , &readfds , NULL , NULL , NULL);

	    		if ((activity < 0))
	    		{
	    			printf("select error");
	    		}



	    		if (FD_ISSET(0, &readfds))
	    		{


	    			gets(input);
	    			//printf("input=%s",input);
	    			printf("\n processing the command entered  \n");
	    			i = 0;

	    			pt = strtok (input," ");


	    			while (pt!= NULL)
	    			{

	    				userinput[i++] = pt;
	    				pt = strtok (NULL," ");
	    				//printf("pt =%s\n",pt);
	    			}



	    			/*argc=0;
	    			pt=strtok(input," ");
	    			while(pt != NULL)
	    			{
	    				strcpy(argv[argc],pt);
	    				argc +=1;
	    				pt=strtok(NULL," ");
	    			}*/

	    			//CREATOR

	    			if (strcmp(userinput[0],"creator")==0)
	    			{
	    				printf("\nCREATOR\n");
	    				printf("\n\nUBIT name : rshetty \nUBemail: rshetty@buffalo.edu\n");
	    				printf("\nI have read and understood the course academic integrity policy at http://www.cse.buffalo.edu/faculty/dimitrio/courses/cse4589_f14/index.html#integrity\n\n");

	    			}

	    			//HELP

	    			else if (strcmp(userinput[0],"help")==0)
	    			{
	    				printf("\nHELP\n");
	    				printf("\n welcome to the help menu,all the commands that can be used are given below\n\n");
	    				printf("\n creator: information of the creator can be found here\n");
	    				printf("\n myip: ipaddress of the process\n");
	    				printf("\n myport : used to display the port number on which the machine is listening for incoming connections\n");
	    				printf("\n register <server ip> <port> : register with server whos ip is <server ip> and port number is<port>\n");
	    				printf("\n connect <destination> <port> : connect to a fellow client by providing hostname/ip and port number\n");
	    				printf("\n list : list of all active connections is displayed\n");
	    				printf("\n terminate <connection id> : connection mentioned through <connection id> will be terminated\n");
	    				printf("\n exit : all connections will be terminated\n");
	    				printf("\n upload <connection_id> <file_name> : the file specified at<file_name> is uploaded to the mentioned <connection_id>\n");
	    				printf("\n download <connection_id1> <file_name1> <connection_id2> <file_name2> <connection_id3> <file_name3> : download files from serveres specified through <connection_id1> <connection_id2> <connection_id3> \n");
	    				printf("\n statistics : servers updated statistics is displayed \n for client display client statistics \n");
	    				printf("\n");

	    			}

	    			//IP


	    			else if (strcmp(userinput[0],"myip")==0)
	    			{
	    				strcpy(ipaddr,myip());
	    				printf("%s",ipaddr);
	    			}


	    			//PORT


	    			else if (strcmp(userinput[0],"myport")==0)
	    			{



	        			int size = sizeof(struct sockaddr);
	        			if (getsockname(master_socket, (struct sockaddr *)&sin, &size) == -1)
	        			{
	        				perror("\n getsockname \n");
	        			}
	        			else
	        			{
	        				portno=ntohs(sin.sin_port);
	        				printf("\n port number:%d\n",portno);
	        				//return portno;
	        			}
	        		}




	    			else if (strcmp(userinput[0],"list")==0)
	    			{
	    				printf("\n\n");
	    				s[0].portno=portno;
	    				strcpy(s[0].hostname,hostname);
	    				strcpy(s[0].ipaddr,MY_IP);//.............

	    				int size = sizeof(struct sockaddr);
	    				if (getsockname(master_socket, (struct sockaddr *)&sin, &size) == -1)
	    				{
	    					perror("getsockname");
	    				}
	    				else
	    				{
	    					portno=ntohs(sin.sin_port);
	    				}



	    				printf("%-5s%-35s%-20s%-8s\n","ID","HOSTNAME","IPADDRESS","PORT");
	    				i=0; //Re-declaration;
	    				for (i=0;i<5;i++)
	    				{
	    					if (s[i].id!=0)
	    					{

	    						printf("%-5d%-35s%-20s%-8d\n",(--s[i].id),s[i].hostname,s[i].ipaddr,s[i].portno);
	    					}
	    					else
	    					{
	    						printf("%-5d%-35s%-20s%-8d\n",s[i].id,s[i].hostname,s[i].ipaddr,s[i].portno);
	    					}

	    				}
	    			}
	    			else if (strcmp(userinput[0],"register")==0)
	    			{
	    				clsockfd=registerClient(master_socket,userinput);
	    				i=0;

	    				for (j=0;j<5;j++)
	    				{
	    					printf("entered j loop passval=%s",passVal);
	    					s[j].id=atoi(passVal[i++]);
	    					strcpy(s[j].hostname,passVal[i++]);									//strlen(passVal[i++])
	    					strcpy(s[j].ipaddr, passVal[i++]);
	    					s[j].portno=atoi(passVal[i++]);
	    					if (passVal[i]==NULL)
	    						break;
	    				}

	    				//Set details in client list when client connects
	    				c[0].id=1;
	    				memcpy(c[0].hostname,s[0].hostname,strlen(s[0].hostname));
	    				memcpy(c[0].ipaddr,s[0].ipaddr,strlen(s[0].ipaddr));
	    				c[0].portno=s[0].portno;

	    				if(clsockfd>0)
	    					c[0].sockfd=clsockfd;
	    			}



	    			else if (strcmp(userinput[0],"connect")==0)
	    			{
	    				n=-1;
	    				printf("\n userinput 1=%s,userinput 2=%s \n",userinput[1],userinput[2]);
	    				for (j=1;j<5;j++)

	    				{

	    					if(strcmp(userinput[1],s[j].hostname)==0)
	    					{
	    						userinput[1]=s[j].ipaddr;
	    						break;
	    					}
	    				}

	    				for (j=1;j<5;j++)
	    				{
	    					if ((strcmp(userinput[1],s[j].ipaddr)==0)&&(s[j].portno=atoi(userinput[2]))&&strcmp(ipaddr,s[j].ipaddr)!=0)
	    					{
	    						n=1;
	    						strcpy(hostname,s[j].hostname);
	    						strcpy(ipaddr,s[j].ipaddr);
	    						portno=s[j].portno;
	    						break;
	    					}
	    				}
	    				if (n!=1)
	    					printf("\n connect was used with incorrect arguments\n PLEASE NOTE:do not connect with server or self\n");

	    				else
	    				{
	    					for (i=0;i<maxclients;i++)
	    					{
	    						if (c[i].id==0)
	    						{
	    							n=1;
	    							break;
	    						}
	    					}
	    					if (n=1)
	    					{
	    						peerconsockfd=fellowclientconnections(userinput,s);
	    						printf("\n\n\nValue of peerconsockfd after return %d\n\n\n",peerconsockfd);
	    						if (peerconsockfd>0)
	    						{
	    							for (i=0;i<maxclients;i++)
	    							{

	    								if (c[i].id==0)
	    								{
	    									c[i].id=i+1;
	    									strcpy(c[i].hostname,hostname);
	    									strcpy(c[i].ipaddr,ipaddr);
	    									c[i].portno=portno;
	    									c[i].sockfd=peerconsockfd;
	    									break;
	    								}
	    							}
	    						}
	    					}
	    					else
	    						perror("\nClient has already registered with max number of peers\n");
	    				}

	    			}

	    			//exit
	    			else if (strcmp(userinput[0],"exit")==0)
	    			{

	    				j=-1;
	    				int k=0;
	    				int test;


	    				for (k=0;k<maxclients;k++)
	    				{
	    					if (c[k].sockfd!=0)
	    					{
	    						new_socket=c[k].sockfd;

	    						bzero(buffer,1025);
	    						strcpy(buffer,"terminate");

	    						if( (test=send(new_socket, buffer , strlen(buffer) , 0)) < 0)
	    							perror("\n failed to send \n");

	    						else
	    						{

	    							if ((test = recv(new_socket, buffer, 1025,0)) < 0)
	    								perror("\n failed to recieve \n");
	    							else
	    							{
	    								perror("\n recieve confirmed\n");
	    								for (i=0;i<maxclients;i++)
	    								{
	    									if (new_socket==clientfd[i])
	    										clientfd[i]=-1;
	    									if (c[i].sockfd==new_socket)
	    									{
	    										c[i].id=0;
	    										strcpy(c[i].hostname,"...");
	    										strcpy(c[i].ipaddr,"...");
	    										c[i].portno=0;
	    										c[i].sockfd=0;
	    									}
	    								}
	    								close(new_socket);
	    							}
	    						}
	    					}
	    				}
	    			}


	    			else if (strcmp(userinput[0],"terminate")==0)
	    			{
	    				int test;

	    				n=atoi(userinput[1]);
	    				j=-1;
	    				for (i=0;i<maxclients;i++)
	    				{
	    					if (n==c[i].id)
	    					{
	    						terminatesock=c[i].sockfd;

	    						j=1;
	    						break;
	    					}
	    				}
	    				if (j!=1)
	    					printf("\n please check if the client you want to terminate exists\n");
	    				else
	    				{
	    					bzero(buffer,1025);
	    					strcpy(buffer,"terminate");

	    					if( (test=send(terminatesock, buffer , strlen(buffer) , 0)) < 0)
	    						perror("\n full message unable to send\n");
	    					else
	    					{

	    						if ((n = recv(terminatesock, buffer, 1025,0)) < 0)
	    							perror("\n failed to recieve \n");
	    						else
	    						{
	    							for (i=0;i<maxclients;i++)
	    							{
	    								if (terminatesock==clientfd[i])
	    									clientfd[i]=-1;
	    								if (c[i].sockfd==terminatesock)
	    								{
	    									c[i].id=0;
	    									strcpy(c[i].hostname,"...");
	    									strcpy(c[i].ipaddr,"...");
	    									c[i].portno=0;
	    									c[i].sockfd=0;
	    								}
	    							}

	    							close(terminatesock);

	    						}
	    					}
	    				}

	    			}



	    			else if (strcmp(userinput[0],"upload")==0)
	    			{
	    				FILE *fp;
	    				int sd,newsd,ser,n,a,cli,pid,bd,port,clilen;
	    				char name[100],fileread[100],fname[100],ch,file[100],rcv[100];
	    				struct sockaddr_in servaddr,cliaddr;
	    				port=portno;
	    				printf("port inside upload =%d",port);


	    				sd=socket(AF_INET,SOCK_STREAM,0);

	    				if(sd<0)
	    					printf("Cant create\n");
	    				else
	    					printf("Socket is created\n");



	    				servaddr.sin_family=AF_INET;
	    				servaddr.sin_addr.s_addr=htonl(INADDR_ANY);
	    				servaddr.sin_port=htons(port);

	    				a=sizeof(servaddr);
	    				bd=bind(sd,(struct sockaddr *)&servaddr,a);
	    				if(bd<0)
	    					printf("Cant bind\n");
	    				else
	    					printf("Binded\n");

	    				listen(sd,5);
	    				clilen=sizeof(cliaddr);

	    				newsd=accept(sd,(struct sockaddr *)&cliaddr,&clilen);

	    				if(newsd<0)
	    				{
	    					printf("Cant accept\n");
	    				}
	    				else
	    					printf("Accepted\n");

	    				n=recv(newsd,rcv,100,0);
	    				rcv[n]='\0';

	    				n=atoi(userinput[1]);
	    				j=-1;
	    				for (i=0;i<maxclients;i++)
	    				{
	    					if (n==c[i].id)
	    					{
	    						sd=c[i].sockfd;
	    						strcpy(hostname,c[i].hostname);
	    						j=1;
	    						break;
	    					}
	    				}
	    				if (j!=1)
	    					printf("\ninvalid command please check list\n");
	    				else
	    				{

	    					bzero(buffer,1025);
	    					strcpy(buffer,"upload");

	    					sleep(1);
	    					bzero(rcv, 100);
	    					strcpy(rcv,"./");
	    					strcat(rcv,userinput[2]);

	    					fp=fopen(rcv,"r");
	    					if(fp==NULL)
	    					{
	    						send(newsd,"error",5,0);
	    						close(newsd);
	    					}
	    					else
	    					{
	    						int bytes=sizeof(fileread);
	    						gettimeofday(&start, NULL);
	    						while(fgets(fileread,sizeof(fileread),fp))
	    						{
	    							if(send(newsd,fileread,sizeof(fileread),0)<0)
	    							{
	    								printf("Cant send\n");
	    							}
	    							i=i+bytes;
	    							sleep(1);
	    						}
	    						if(!fgets(fileread,sizeof(fileread),fp))
	    						{
	    							send(newsd,"completed",999999999,0);
	    						}
	    						gettimeofday(&end, NULL);

	    						timeS =  (end.tv_sec - start.tv_sec) + ((end.tv_usec - start.tv_usec)/1000000.0);
	    						txnrate=i/timeS;
	    						printf("\n\n\n Tx %s -> %s, File Size: %d Bytes, Time Taken %f seconds, Tx Rate = %f bits/sec\n\n\n",myhost, hostname,i,timeS,txnrate);

	    						printf("\n\nOk File %s from Client was Sent!\n", userinput[2]);
	    						n=0;
	    						printf("\n hostname= %s first slot in stasts = %s\n",hostname,st[0].host2);

	    						for (i=0;i<30;i++)
	    						{
	    							if(strcmp(st[i].host2,hostname)==0)
	    							{

	    								st[i].uploadtime=((st[i].uploadtime*st[i].uploadnum)+txnrate)/(st[i].uploadnum+1);
	    								st[i].uploadnum=st[i].uploadnum+1;
	    								n=1;
	    								break;
	    							}
	    						}
	    						if (n!=1)
	    						{

	    							for (i=0;i<30;i++)
	    							{
	    								if(st[i].id==0)
	    								{
	    									//insert and break
	    									st[i].id=i+1;
	    									strcpy(st[i].host1,myhost);
	    									strcpy(st[i].host2,hostname);
	    									st[i].uploadtime=txnrate;
	    									st[i].uploadnum=1;
	    									n=1;
	    									break;
	    								}
	    							}
	    						}



	    					}

	    				}
	    			}




	    			else if (strcmp(userinput[0],"download")==0)
	    			{
	    				FILE *fp,*fp2;
	    				int csd,n,ser,s,cli,cport,newsd;

	    				char name[100],rcvmsg[100],rcvg[100],fname[100];
	    				struct sockaddr_in servaddr;


	    				cport=portno;
	    				csd=socket(AF_INET,SOCK_STREAM,0);


	    				if(csd<0)
	    				{
	    					printf("Error....\n");
	    					exit(0);
	    				}
	    				else
	    					printf("Socket is created\n");

	    				servaddr.sin_family=AF_INET;
	    				servaddr.sin_addr.s_addr=htonl(INADDR_ANY);
	    				servaddr.sin_port=htons(cport);

	    				if(connect(csd,(struct sockaddr *)&servaddr,sizeof(servaddr))<0)
	    					printf("Error in connection\n");
	    				else
	    					printf("connected\n");


	    				for (i=1;i<10;i=i+2)
	    				{

	    					if ((strcmp(userinput[i],"-")!=0)&&(strcmp(userinput[i+1],"-")!=0))
	    					{

	    						n=atoi(userinput[i]);

	    						j=-1;
	    						for (i=0;i<maxclients;i++)
	    						{
	    							if (n==c[i].id)
	    							{
	    								csd=c[i].sockfd;
	    								printf("\n Value of up sock in upload is %d\n\n", csd);
	    								j=1;
	    								break;
	    							}
	    						}


	    						if (j!=1)
	    							printf("\n invalid client check list for available clients\n");
	    						else
	    						{
	    							bzero(buffer,1025);
	    							strcpy(buffer,"download");

	    							if( send(csd, buffer , strlen(buffer) , 0)< 0)
	    							{
	    								perror("\n send failed");
	    								exit(EXIT_FAILURE);
	    							}
	    							else
	    							{
	    								bzero(buffer,1025);
	    								strcpy(buffer,userinput[i+1]); //Set file name
	    								sleep(5);

	    								if( send(csd, buffer , strlen(buffer) , 0) < 0)
	    									perror("\nfile name send failed");
	    								else
	    								{

	    									bzero(fname, 200);
	    									strcpy(fname,"./");
	    									strcat(fname,buffer);
	    									strcat(fname,"_rakshith");


	    									fp2=fopen(fname,"w");
	    									send(csd,fname,sizeof(fname),0);


	    									bzero(rcvg, length);
	    									int bytes= 0;
	    									i=0;
	    									gettimeofday(&start, NULL);
	    									while((bytes= recv(csd, rcvg, length, 0)) > 0)
	    									{
	    										i=i+bytes;
	    										if((writesize = fwrite(uploadbuffer, sizeof (char), bytes, fp2)) < 0)
	    										{
	    											perror(" failed file write \n");
	    										}
	    										if (bytes== 0 || bytes!= length)
	    										{
	    											break;
	    										}
	    										bzero(uploadbuffer, length);

	    									}

	    									gettimeofday(&end, NULL);
	    									timeS =  (end.tv_sec - start.tv_sec) + ((end.tv_usec - start.tv_usec)/1000000.0);

	    									txnrate=i/timeS;
	    									printf("\n\n\n Rx %s -> %s, File Size: %d Bytes, Time Taken %f seconds, Rx Rate = %f bits/sec\n\n\n",hostname,myhost,i,timeS,txnrate);


	    									rcvg[s]='\0';
	    									if(strcmp(rcvg,"error")==0)
	    										printf("File is not available\n");
	    									if(strcmp(rcvg,"completed")==0)
	    									{
	    										printf("File is transferred........\n");
	    										fclose(fp2);
	    										close(csd);

	    										printf("\n hostname  : %s first slot in stasts = %s\n",hostname,st[0].host2);


	    										for (i=0;i<30;i++)
	    										{
	    											if(strcmp(st[i].host2,hostname)==0)
	    											{

	    												st[i].downloadtime=((st[i].downloadtime*st[i].downloadnum)+txnrate)/(st[i].downloadnum+1);
	    												st[i].downloadnum=st[i].downloadnum+1;
	    												n=1;
	    												break;
	    											}
	    										}
	    										if (n!=1)
	    										{

	    											for (i=0;i<30;i++)
	    											{
	    												if(st[i].id==0)
	    												{

	    													st[i].id=i+1;
	    													strcpy(st[i].host1,myhost);
	    													strcpy(st[i].host2,hostname);
	    													st[i].downloadtime=txnrate;
	    													st[i].downloadnum=1;
	    													n=1;
	    													break;
	    												}
	    											}



	    										}
	    										else
	    											fputs(rcvg,stdout);

	    										fprintf(fp,"%s",rcvg);
	    									}
	    								}
	    							}
	    						}
	    					}
	    				}
	    			}



	    			else if (strcmp(userinput[0],"statistics")==0)
	    			{
	    				printf("\n\n hostname\total uploads\t upload speed\t total downloads\t average download  speed\n\n");
	    				for (i=0;i<40;i++)
	    				{

	    					if(st[i].id!=0)
	    					{
	    						printf("\n%s \t%d \t%f \t%d \t%f\n",st[i].host2,st[i].uploadnum,st[i].uploadtime,st[i].downloadnum,st[i].downloadtime);
	    					}
	    				}
	    			}
















	    			else
	    			{
	    				printf("\n error: invalid command check list of commands using help\n");
	    			}

	    		}




	    		//If something happened on the master socket , then its an incoming connection
	    		if (FD_ISSET(master_socket, &readfds))
	    		{
	    			if ((new_socket = accept(master_socket, (struct sockaddr *)&address, (socklen_t*)&addrlen))<0)
	    			{
	    				perror("accept");
	    				exit(EXIT_FAILURE);
	    			}

	    			//inform user of socket number - used in send and receive commands
	    			printf("New connection , socket fd is %d , ip is : %s , port : %d \n" , new_socket , inet_ntoa(address.sin_addr) , ntohs(address.sin_port));

	    			//send new connection greeting message
	    			if( send(new_socket, message, strlen(message), 0) != strlen(message) )
	    			{
	    				perror("send");
	    			}

	    			puts("Welcome message sent successfully");

	    			//add new socket to array of sockets
	    			for (i = 0; i < max_clients; i++)
	    			{
	    				//if position is empty
	    				if( client_socket[i] == 0 )
	    				{
	    					client_socket[i] = new_socket;
	    					printf("Adding to list of sockets as %d\n" , i);

	    					break;
	    				}
	    			}
	    			for (j=0;j<maxclients;j++)
	    			{
	    				if (c[j].id==0)
	    				{
	    					c[j].id=j+1;
	    					hostentry=gethostbyaddr(&address.sin_addr, sizeof (address.sin_addr), AF_INET);
	    					strcpy(c[j].hostname,hostentry->h_name);
	    					inet_ntop(AF_INET, &address.sin_addr, c[j].ipaddr, 99);
	    					c[j].portno=atoi(buffer);
	    					c[j].sockfd=new_socket;
	    					break;
	    				}
	    			}





	    		}

	    		//else its some IO operation on some other socket :)
	    		for (i = 0; i < max_clients; i++)
	    		{
	    			sd = client_socket[i];
	    			strcpy(hostname,c[i].hostname);
	    			if(clientfd[i]>0)
	    			{
	    				if (FD_ISSET( sd , &readfds))
	    				{

	    					bzero(buffer,1025);
	    					//Check if it was for closing , and also read the incoming message
	    					if ((valread = read( sd , buffer, 1025)) == 0)
	    					{
	    						//Somebody disconnected , get his details and print
	    						getpeername(sd , (struct sockaddr*)&address , (socklen_t*)&addrlen);
	    						printf("Host disconnected , ip %s , port %d \n" , inet_ntoa(address.sin_addr) , ntohs(address.sin_port));

	    						//Close the socket and mark as 0 in list for reuse
	    						close( sd );
	    						client_socket[i] = 0;
	    					}

	    					else if (strcmp(buffer,"terminate")==0)
	    					{
	    						printf("\n message :%s\n",buffer);



	    						for (i=0;i<maxclients;i++)
	    						{
	    							if (new_socket==clientfd[i])
	    								clientfd[i]=-1;
	    							if (c[i].sockfd==new_socket)
	    							{
	    								c[i].id=0;
	    								strcpy(c[i].hostname,"...");
	    								strcpy(c[i].ipaddr,"...");
	    								c[i].portno=0;
	    								c[i].sockfd=0;
	    							}
	    						}

	    						if( (send(new_socket, buffer , strlen(buffer) , 0)) < 0)
	    							puts("send failed\n");
	    						else
	    							printf("\nsocket id=%d  deleted",new_socket);
	    							close(new_socket);
	    					}

	    					else if(strcmp(buffer,"upload")==0)
	    					{
	    						FILE *fp;
	    						FILE *fp2;
	    						int sd,newsd,ser,n,a,cli,pid,bd,port,clilen;
	    						char name[100],fileread[100],fname[100],ch,file[100],rcv[100];
	    						struct sockaddr_in servaddr,cliaddr;
	    						port=portno;
	    						printf("port inside upload =%d",port);
	    						bzero(buffer, 1025);

	    						if ((n = recv(new_socket, buffer, 1025,0)) < 0)
	    							puts("filename send failed\n");
	    						else if(n>0)
	    						{
	    							bzero(rcv, 100);
	    							strcpy(rcv,"./");
	    							strcat(rcv,buffer);
	    							strcat(rcv,"_rakshith");
	    							printf("buffer value: %s",buffer);

	    							printf("\n\nfilename : %s",rcv);

	    							fp2 = fopen(rcv, "ab+");
	    							if(fp2 == NULL)
	    								printf("file %s cannot be opened\n", rcv);
	    							else
	    							{
	    								int bytes=sizeof(fileread);

	    								bytes= 0;
	    								i=0;
	    								gettimeofday(&start, NULL);
	    								while(fgets(fileread,sizeof(fileread),fp))
	    									while((bytes= recv(new_socket, rcv, length, 0)) > 0)
	    									{

	    										printf("block size: %d and writesize:%d",bytes,writesize);


	    										if((writesize = fwrite(rcv, sizeof (char), bytes, fp2)) < 0)
	    										{
	    											puts("failed file write\n");
	    										}
	    										i=i+bytes;

	    										if (bytes== 0 || bytes!= length)
	    										{
	    											break;
	    										}
	    										bzero(rcv, length);

	    									}
	    								gettimeofday(&end, NULL);
	    								timeS =  (end.tv_sec - start.tv_sec) + ((end.tv_usec - start.tv_usec)/1000000.0);

	    								txnrate=i/timeS;
	    								printf("\n\n\n Rx %s -> %s, File Size: %d Bytes, Time Taken %f seconds, Rx Rate = %f bits/sec\n\n\n",hostname,myhost,i,timeS,txnrate);

	    								if(bytes< 0)
	    								{
	    									puts("recieve failed");
	    								}
	    								printf(" received from client!\n");
	    								fclose(fp2);

	    							}
	    						}
	    					}




	    					else if(strcmp(buffer,"download")==0)
	    					{
	    						FILE *fp,*fp2;
	    						int csd,n,ser,s,cli,cport,newsd;

	    						char name[100],rcvmsg[100],rcvg[100],fname[100];
	    						struct sockaddr_in servaddr;
	    						bzero(buffer, 1025);
	    						int bytes;

	    						n = recv(new_socket, buffer, 1025,0);
	    						if (n< 0)
	    							puts("recieve failed\n");
	    						else if(n>0)
	    						{
	    							sleep(2);
	    							bzero(rcvg, 100);
	    							strcpy(rcvg,"./");
	    							strcat(rcvg,buffer);

	    							// Open the filefo reading...

	    							fp = fopen(rcvg,"r");
	    							if (!fp)
	    							{
	    								perror("unable to open file\n");

	    							}
	    							bzero(rcvg,length);
	    							i=0;
	    							gettimeofday(&start, NULL);
	    							while((bytes=fread(rcvg, sizeof (char),length, fp))>0)
	    							{
	    								printf("\n\nbytes read %d",bytes);
	    								i=i+bytes;
	    								if(send(new_socket, rcvg, bytes, 0) < 0)
	    								{
	    									perror("file sending failed");
	    									break;
	    								}
	    								printf("uploadbuffer: %s",rcvg);
	    								bzero(rcvg, length);
	    							}//end while for send file
	    							gettimeofday(&end, NULL);

	    							timeS =  (end.tv_sec - start.tv_sec) + ((end.tv_usec - start.tv_usec)/1000000.0);
	    							txnrate=i/timeS;
	    							printf("\n\n\n Tx %s -> %s, File Size: %d Bytes, Time Taken %f seconds, Tx txnrate = %f bits/sec\n\n\n",myhost, hostname,i,timeS,txnrate);

	    							printf("\n\n peer sent file %s!\n", userinput[2]);

	    						}
	    					}

	    					//Echo back the message that came in
	    					else
	    					{

	    						i = 0;
	    						pt = strtok (buffer," ");
	    						while (pt != NULL)
	    						{
	    							passVal[i++] = pt;
	    							pt = strtok (NULL, " ");
	    						}
	    						passVal[i]='\0';
	    						printf("tokenizing successful");
	    						i=0;

	    						for (j=0;j<5;j++)
	    						{
	    							s[j].id=atoi(passVal[i++]);
	    							strcpy(s[j].hostname,passVal[i++]);
	    							strcpy(s[j].ipaddr, passVal[i++]);
	    							s[j].portno=atoi(passVal[i++]);
	    							if (passVal[i]==NULL)
	    								break;
	    						}
	    						i=0; //Re-declaration;
	    						printf("ID\tHOSTNAME\tIPADDRESS\tPORT\n\n");
	    						for (i=0;i<5;i++)
	    						{
	    							printf("\n%d\t%s\t%s\t%d\t",s[i].id,s[i].hostname,s[i].ipaddr,s[i].portno);
	    						}
	    					}
	    				}
	    			}
	    		}
	    	}
	    }
return;
}































 int registerClient(int socket_desc, char **argv)
 {


	 struct sockaddr_in server;
	 char message[1000] , server_reply[2000];
	 char *p;
	 struct servL s[5];

	 /*fill the list with initial value of server*/


	 for (i=0;i<5;i++)
	 {
		 s[i].id=0;
		 strcpy(s[i].hostname,"...");
		 strcpy(s[i].ipaddr,"...");
		 s[i].portno=0;
		 s[i].sockfd=0;
	 }


	 //Create socket
	 clsockfd = socket(AF_INET , SOCK_STREAM , 0);
	 if (clsockfd == -1)
	 {
		 printf("Could not create socket");
	 }
	 puts("Socket created");

	 server.sin_addr.s_addr = inet_addr(argv[1]);
	 server.sin_family = AF_INET;
	 server.sin_port = htons(atoi(argv[2]));

	 //Connect to remote server
	 if (connect(clsockfd , (struct sockaddr *)&server , sizeof(server)) < 0)
	 {
		 perror("connect failed. Error");
		 return 0;
	 }

	 puts("Connected\n");
	 printf("\n portnum = %d\n",portno);
	 sprintf(message, "%d", portno);
	 printf  ("sent port number : %s\n\n", message);


	 //keep communicating with server
	 //while(1)

		 //Send some data
		 if( send(clsockfd , message , strlen(message) , 0) < 0)
		 {
			 puts("Send failed");
			 return 0;
		 }
		 else
		 {
			 printf("port no sent successfully from register client to server");
		 }
		 //Receive a reply from the server
		 if( recv(clsockfd , server_reply , 1000 , 0) < 0)
		 {
			 puts("recv failed");
			 //break;
		 }

		 puts("Server reply :");
		 puts(server_reply);
		 for (i = 0; i < maxclients; i++)
		 {

			 if( clientfd[i] == -1 )
			 {
				 clientfd[i] = clsockfd;
				 printf("\n Register success: client socket added at %d \n",i);
				 break;
			 }
		 }



		 i = 0;
		 printf("Vasul: Register()>server_reply \"%s\"\n",server_reply);
		 p = strtok (server_reply," ");
		 printf("Vasul: Register()>p \"%s\"\n",p);
		 while (p != NULL)
		 {
			 printf("Vasul: Register()>p \"%s\"\n",p);
			 strcpy(userinput[i++], p);
			 printf("Vasul: Register(%d)> passVal \"%s\"\n", i, userinput);
			 p = strtok (NULL, " ");
		 }
		 passVal[i]='\0';
		 printf("\n\n tokenizing success\n\n");

		 i=0;

		 for (j=0;j<5;j++)
		 {
			 printf("Vasul: Register(1)> passVal \"%s\"\n", passVal);
			 s[j].id=atoi(passVal[i++]);
			 printf("Vasul: Register(2)> passVal \"%s\"\n", passVal);
			 strcpy(s[j].hostname,passVal[i++]);
			 printf("Vasul: Register(3)> passVal \"%s\"\n", passVal);
			 strcpy(s[j].ipaddr, passVal[i++]);
			 printf("Vasul: Register(4)> passVal \"%s\"\n", passVal);
			 s[j].portno=atoi(passVal[i++]);
			 printf("Vasul: Register(5)> passVal \"%s\"\n", passVal);
			 if (passVal[i]==NULL)
			 {
				 printf("Vasul: Register()> passVal \"%s\"\n", passVal);
				 break;
			 }

		 }
		 i=0;
		 printf("\n%-5s%-35s%-20s%-8s\n","ID","HOSTNAME","IPADDRESS","PORT");
		 for (i=0;i<5;i++)
		 {
			 printf("\n%-5d%-35s%-20s%-8d\n",s[i].id,s[i].hostname,s[i].ipaddr,s[i].portno);
		 }



	 return clsockfd;

}





 int fellowclientconnections(char **argv, struct servL s[5])
 {
	 struct sockaddr_in clientconnect;
	 char message[1000] , server_reply[2000];
	 char *p;

	 for (j=1;j<5;j++)
	 {

		 if(strcmp(argv[1],s[j].hostname)==0)
		 {
			 argv[1]=s[j].ipaddr;
			 break;
		 }
	 }



	 //Create socket
	 peerconsockfd= socket(AF_INET , SOCK_STREAM , 0);
	 if (peerconsockfd == -1)
	 {
		 printf("Could not create socket");
	 }
	 puts("Socket created");

	 clientconnect.sin_addr.s_addr = inet_addr(argv[1]);
	 clientconnect.sin_family = AF_INET;
	 clientconnect.sin_port = htons( atoi(argv[2]) );

	 //Connect to remote server
	 if (connect(peerconsockfd , (struct sockaddr *)&clientconnect , sizeof(clientconnect)) < 0)
	 {
		 perror("connect failed. Error");
		 return 0;
	 }

	 puts("Connected\n");



	 //keep communicating with server
	 while(1)
	 {
		 printf("\n portnum = %d\n",portno);
		 sprintf(message, "%d", portno);
		 printf  ("sent port number : %s\n\n", message);

		 //Send some data
		 if( send(peerconsockfd , message , strlen(message) , 0) < 0)
		 {
			 puts("Send failed");
			 return 0;
		 }

		 //Receive a reply from the server
		 if( recv(peerconsockfd , server_reply , 2000 , 0) < 0)
		 {
			 puts("recv failed");
			 break;
		 }



		 for (i = 0; i < maxclients; i++)
		 {

			 if( clientfd[i] == -1 )
			 {
				 clientfd[i] = peerconsockfd;
				 printf("Peer  socket fd added at %d after connect success",i);
				 break;
			 }
		 }
	 }
	 return peerconsockfd;


 }









int main (int argc[], char *argv[])
{

	char *var=argv[1];

	if (strcmp(var,"s")==0)
	{

		printf("\n for server \n");
		server(*var, argv);
	}
	else if(strcmp(var,"c")==0)
	{

		printf("\n for client\n");
		client(*var, argv);
	}
	else
	{
		printf("\n wrong input \n");

	}
	return 0;
}
